const ABECEDARIO = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ";
const INTENTOSMAXIMOS = 7;
const ENMASCARAR = "_";

const letras = {};
let palabraOculta = [];
let intentosRestantes = 0;

document.addEventListener("DOMContentLoaded", () => {
    reiniciarJuego();
});

function reiniciarJuego() {
    crearBotones();
}


function crearBotones() {
    const contenedorBotones = document.querySelector(".col-12");

    for (const letra of ABECEDARIO) {
        letras[letra] = letra;


        const boton = document.createElement("button");
        boton.textContent = letra;
        boton.className = "btn btn-dark btn-lg";
        boton.style.marginRight = "2px";
        boton.dataset.letra = letra;
        contenedorBotones.appendChild(boton);

    }
}





