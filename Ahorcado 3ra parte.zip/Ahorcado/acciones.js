const ABECEDARIO = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ";
const INTENTOSMAXIMOS = 7;
const ENMASCARAR = "_";

const letras = {};
let palabraOculta = [];
let intentosRestantes = 0;

document.addEventListener("DOMContentLoaded", () => {
    reiniciarJuego();
}); 
function reiniciarJuego() {
    crearBotones();
    elegirPalabra();
    actualizarVista();
}


function elegirPalabra() {
    const palabras = ["durazno","reloj","manzana", "lunes", "eucalipto", "pelota", "mariposa", "teclado","diversificado","tortuga","carro","medicina","cuaderno","escritorio","estadio","equipo","partido"];
    const palabra = palabras[Math.floor(Math.random() * palabras.length)];
    prepararPalabra(palabra);
}

function prepararPalabra(palabra) {
    palabra = palabra.toUpperCase();
    palabraOculta = [];
    for (const letra of palabra) {
        palabraOculta.push({
            letra,
            hidden: true
        });
    }
}

function mostrarPalabra() {
    let palabraMostrada = "";
    for (const letra of palabraOculta) {
        if (letra.hidden) {
            palabraMostrada += ENMASCARAR;
        } else {
            palabraMostrada += letra.letra;
        }
        palabraMostrada += " ";
    }
    return palabraMostrada;
}

function crearBotones() {
    const contenedorBotones = document.querySelector(".col-12");

    for (const letra of ABECEDARIO) {
        letras[letra] =letra;         

        const boton = document.createElement("button");
        boton.textContent = letra;
        boton.className = "btn btn-dark btn-lg";
        boton.style.marginRight = "2px";
        boton.dataset.letra = letra; 
        contenedorBotones.appendChild(boton);
    }
}


function actualizarVista() {
    const intentos = document.querySelector(".text-danger");

    document.querySelector(".displayed-word").textContent = "Palabra: " + mostrarPalabra();
}


